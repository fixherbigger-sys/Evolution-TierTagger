package net.evolutiontiers.tagger.tierlist;

import net.evolutiontiers.tagger.TierTagger;
import net.evolutiontiers.tagger.model.GameMode;
import net.evolutiontiers.tagger.model.PlayerInfo;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.PlayerSkinWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.uku3lig.ukulib.config.screen.CloseableScreen;
import org.jetbrains.annotations.NotNull;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

public class PlayerInfoScreen extends CloseableScreen {
    private final PlayerInfo info;
    private final PlayerSkinWidget skin;

    public PlayerInfoScreen(Screen parent, PlayerInfo info, PlayerSkinWidget skin) {
        super(Component.literal("Player Info"), parent);
        this.info = info;
        this.skin = skin;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, ignored -> Minecraft.getInstance().setScreen(parent))
                .bounds(this.width / 2 - 100, this.height - 27, 200, 20)
                .build());

        this.addRenderableWidget(this.skin);

        int rankingHeight = this.info.rankings().size() * 11;
        int infoHeight = 56; // 4 lines of text (10 px tall) + 6 px padding
        int startY = (this.height - infoHeight - rankingHeight) / 2;
        int rankingY = startY + infoHeight;

        for (PlayerInfo.NamedRanking namedRanking : this.info.getSortedTiers()) {
            // ugly "fix" to avoid crashes if upstream doesn't have the right names
            if (namedRanking.mode() == null) continue;

            StringWidget text = new StringWidget(formatTier(namedRanking.mode(), namedRanking.ranking()), this.font);
            text.setX(this.width / 2 + 5);
            text.setY(rankingY);

            Instant attained = namedRanking.ranking().attainedInstant();
            String date = attained == null ? "Unknown" : DateTimeFormatter.ISO_LOCAL_DATE.withZone(ZoneOffset.UTC).format(attained);
            Component tooltipText = Component.literal("Attained: " + date + "\nPoints: " + namedRanking.ranking().points()).withStyle(ChatFormatting.GRAY);
            text.setTooltip(Tooltip.create(tooltipText));
            this.addRenderableWidget(text);
            rankingY += 11;
        }
    }

    @Override
    public void render(@NotNull GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        super.render(graphics, mouseX, mouseY, delta);

        graphics.drawCenteredString(this.font, this.info.ign() + "'s profile", this.width / 2, 20, 0xFFFFFFFF);

        int rankingHeight = this.info.rankings().size() * 11;
        int infoHeight = 56; // 4 lines of text (10 px tall) + 6 px padding
        int startY = (this.height - infoHeight - rankingHeight) / 2;

        graphics.drawString(this.font, getRegionText(this.info), this.width / 2 + 5, startY, 0xFFFFFFFF);
        graphics.drawString(this.font, getPointsText(this.info), this.width / 2 + 5, startY + 15, 0xFFFFFFFF);
        graphics.drawString(this.font, getRankText(this.info), this.width / 2 + 5, startY + 30, 0xFFFFFFFF);
        graphics.drawString(this.font, "Rankings:", this.width / 2 + 5, startY + 45, 0xFFFFFFFF);
    }

    private Component formatTier(@NotNull GameMode gamemode, PlayerInfo.Ranking ranking) {
        Component tierText = TierTagger.getRankingText(ranking, true);

        return Component.empty()
                .append(gamemode.asStyled(true))
                .append(Component.literal(": ").withStyle(ChatFormatting.GRAY))
                .append(tierText);
    }

    private Component getRegionText(PlayerInfo info) {
        return Component.empty()
                .append(Component.literal("Region: "))
                .append(Component.literal(info.region() == null ? "N/A" : info.region()).withStyle(s -> s.withColor(info.getRegionColor())));
    }

    private Component getPointsText(PlayerInfo info) {
        return Component.empty()
                .append(Component.literal("Points: "))
                .append(Component.literal(info.totalPoints() + " ").withStyle(s -> s.withColor(info.getPointInfoColor())))
                .append(Component.literal("(" + info.rankTitle() + ")").withStyle(s -> s.withColor(info.getPointInfoAccentColor())));
    }

    private Component getRankText(PlayerInfo info) {
        int color = switch (info.overallRank()) {
            case 1 -> 0xe5ba43;
            case 2 -> 0x808c9c;
            case 3 -> 0xb56326;
            default -> 0x1e2634;
        };

        return Component.empty()
                .append(Component.literal("Global rank: "))
                .append(Component.literal("#" + info.overallRank()).withStyle(s -> s.withColor(color)));
    }
}
