package net.evolutiontiers.tagger.neoforge;

import com.llamalad7.mixinextras.lib.semver.Version;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.evolutiontiers.tagger.TierTagger;
import net.evolutiontiers.tagger.config.UkulibIntegration;
import net.uku3lig.ukulib.neoforge.UkulibNFProvider;

@Mod(value = TierTagger.MOD_ID, dist = Dist.CLIENT)
public class TierTaggerNeoForge {
    public TierTaggerNeoForge(ModContainer container) {
        String versionString = container.getModInfo().getVersion().toString();
        TierTagger.onInitialize(Version.parse(versionString));
        container.registerExtensionPoint(UkulibNFProvider.class, UkulibIntegration::new);
    }
}
