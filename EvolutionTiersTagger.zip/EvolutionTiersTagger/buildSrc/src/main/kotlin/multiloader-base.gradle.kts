plugins {
    id("java-library")
    id("idea")
}

group = "net.uku3lig"
version = BuildConfig.createVersionString()

base {
    archivesName = rootProject.name + "-" + project.name
}

// Java 21 -- 1.21.x (obfuscated generation) needs 21, NOT 25 (25 is only
// for the newer unobfuscated 26.x line this template originally targeted).
java.toolchain.languageVersion = JavaLanguageVersion.of(21)

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
    options.release.set(21)
}

tasks.withType<GenerateModuleMetadata>().configureEach {
    enabled = false
}

tasks.jar {
    destinationDirectory.set(file(rootProject.layout.buildDirectory).resolve("libs"))
}

repositories {
    mavenCentral()
    maven { url = uri("https://maven.uku3lig.net/releases") }
}
