/**
 * Multi-version build config for the Fabric-only 1.21 -> 1.21.11 range.
 *
 * Pass which version to build with a JVM system property, e.g.:
 *   gradlew :fabric:build -DmcVersion=1.21.11
 *
 * If you don't pass -DmcVersion, it defaults to the newest (1.21.11).
 *
 * IMPORTANT: fabric-api and ukulib both publish a new build ~weekly, and
 * only 1.21.11's coordinates below have been verified against Modrinth as
 * of this writing (fabric-api 0.152.1+26.2 was the *original* pinned value
 * for MC "26.2" only -- it does NOT work for 1.21.x and must not be reused).
 * Every other entry is a placeholder ("TODO") that WILL fail to resolve
 * until you fill in the real build number. Check:
 *   - Fabric API: https://modrinth.com/mod/fabric-api/versions?g=<version>
 *   - ukulib:     https://modrinth.com/mod/ukulib/versions?g=<version>
 */
import org.gradle.api.GradleException

object BuildConfig {
    val MINECRAFT_VERSION: String = System.getProperty("mcVersion", "1.21.11")

    private data class VersionDeps(val fabricLoader: String, val fabricApi: String, val ukulib: String, val yarnBuild: String)

    // Minimum Fabric Loader is largely version-agnostic across this whole
    // range, so one recent value is used for every entry -- double check
    // https://fabricmc.net/develop/ if a specific 1.21.x build complains.
    private const val FABRIC_LOADER = "0.18.4"

    private val VERSIONS: Map<String, VersionDeps> = mapOf(
        "1.21.11" to VersionDeps(FABRIC_LOADER, "0.141.2+1.21.11", "1.10.2+1.21.11", "4"), // verified against Modrinth/Fabric docs
        "1.21.10" to VersionDeps(FABRIC_LOADER, "TODO+1.21.10", "TODO+1.21.10", "TODO"),
        "1.21.9"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.9", "TODO+1.21.9", "TODO"),
        "1.21.8"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.8", "TODO+1.21.8", "TODO"),
        "1.21.7"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.7", "TODO+1.21.7", "TODO"),
        "1.21.6"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.6", "TODO+1.21.6", "TODO"),
        "1.21.5"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.5", "TODO+1.21.5", "TODO"),
        "1.21.4"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.4", "TODO+1.21.4", "TODO"),
        "1.21.3"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.3", "TODO+1.21.3", "TODO"),
        "1.21.2"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.2", "TODO+1.21.2", "TODO"),
        "1.21.1"  to VersionDeps(FABRIC_LOADER, "TODO+1.21.1", "TODO+1.21.1", "TODO"),
        "1.21"    to VersionDeps(FABRIC_LOADER, "TODO+1.21", "TODO+1.21", "TODO"),
    )

    private val deps: VersionDeps = VERSIONS[MINECRAFT_VERSION]
        ?: throw GradleException(
            "No dependency versions configured for Minecraft $MINECRAFT_VERSION in buildSrc/BuildConfig.kt. " +
            "Valid values: ${VERSIONS.keys.joinToString(", ")}"
        )

    val FABRIC_LOADER_VERSION: String = deps.fabricLoader
    val FABRIC_API_VERSION: String = deps.fabricApi
    val UKULIB_VERSION: String = deps.ukulib

    // Yarn mappings are only needed for this OBFUSCATED (1.21.11-and-older)
    // generation -- the newer 26.x line the original template targeted
    // ships unobfuscated and needs none, which is why this field didn't
    // exist before. Check https://fabricmc.net/develop/ or
    // maven.fabricmc.net/net/fabricmc/yarn for the right build number.
    val YARN_MAPPINGS: String = "$MINECRAFT_VERSION+build.${deps.yarnBuild}"

    const val MOD_VERSION: String = "1.0.0"

    // Not publishing to Modrinth yet -- this is just a placeholder so the
    // `modrinth {}` block in multiloader-platform.gradle.kts still compiles.
    // Replace with a real project ID (and set MODRINTH_TOKEN) if/when you
    // set up automated publishing.
    const val MODRINTH_PROJECT_ID: String = "REPLACE_ME"

    fun createVersionString(): String {
        return "$MOD_VERSION+mc$MINECRAFT_VERSION"
    }
}
